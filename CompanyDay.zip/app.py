from flask import Flask, render_template, redirect, url_for, flash, redirect, request
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField
from wtforms.validators import InputRequired, Email, Length, EqualTo
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_mail import Mail, Message
from itsdangerous import URLSafeSerializer
from sqlalchemy import or_
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'Thisissupposedtobesecret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////home/fw1/Desktop/Flask/Prueba1Flask/database.db'

s = URLSafeSerializer('Thisissupposedtobesecret')

#Confirmación de Email
app.config['MAIL_SERVER'] = 'smtp.googlemail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USERNAME'] = 'developingideaseduardo@gmail.com'
app.config['MAIL_PASSWORD'] = 'xoSp282is$+cricLwrew'
app.config['FLASKY_MAIL_SUBJECT_PREFIX'] = '[CompanyDay]'
app.config['FLASKY_MAIL_SENDER'] = 'Eduardo Sebastian'
mail = Mail(app)

def send_email(to, subject, template, url, **kwargs):
    msg = Message(app.config['FLASKY_MAIL_SUBJECT_PREFIX'] + subject, sender=app.config['FLASKY_MAIL_SENDER'], recipients=[to])
    msg.body = render_template(template + '.txt', **kwargs, url=url)
    msg.html = render_template(template + '.html', **kwargs, url=url)
    mail.send(msg)

Bootstrap(app)
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'logIn'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(15), unique=True)
    email = db.Column(db.String(50), unique = True)
    password = db.Column(db.String(80))
    admin = db.Column(db.Boolean, nullable=False, default=False)#Flase:User True:Admin
    confirmed = db.Column(db.Boolean, nullable=False, default=False)
    userhash = db.Column(db.String(50))

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=4, max=15)])
    password = PasswordField('Password', validators=[InputRequired(), Length(min=8, max=80)])
    remember = BooleanField('Remember Me')

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=4, max=15)])
    email = StringField('Email', validators=[InputRequired(), Email(message='Invalid emial'), Length(max=100)])
    password = PasswordField('Password', validators=[InputRequired(), Length(min=8, max=80), EqualTo('confirmPassword', message='Passwords must match')])
    confirmPassword = PasswordField("Confirm Password", validators=[InputRequired()])

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/logIn.html', methods=['GET', 'POST'])
def logIn():
    form = LoginForm()
    if request.method == 'POST':
        user = User.query.filter(User.username==form.username.data).first()
        if user:
            flash('User does Not Exist')
            if user.confirmed == False:
                flash('Please confirm your user using email received!')
            elif check_password_hash(user.password,form.password.data):
                login_user(user, remember=form.remember.data)
                flash('Welcome back {}'.format(current_user.username))
                return redirect(url_for('profile'))
        else:
            flash('Access denied - wrong username or password')

    return render_template('logIn.html', form=form)

@app.route('/registrar.html', methods=['GET', 'POST'])
def registrar():
    form = RegisterForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            hashed_password = generate_password_hash(form.password.data, method='sha256')

            userhash = ''.join(random.choice('AILNOQVBCDEFGHJKMPRSTUXZabcdefghijklmnopqrstuvxz1234567890') for i in range(50))
            url = 'http://{}/confirmuser/{}/{}'.format(request.host,form.username.data,userhash)
            send_email(form.email.data,'Confirm email.', 'mail/confirmuser',url=url)

            new_user = User(username=form.username.data, email=form.email.data, password=hashed_password, userhash=userhash)
            db.session.add(new_user)
            db.session.commit()
            flash('User Creater Succesfully')
            return redirect(url_for('logIn'))
    else:
        flash('Please Register')

    return render_template('registrar.html', form=form)

@app.route('/profile.html')
@login_required
def profile():
    return render_template('profile.html', name=current_user.username)

@app.route('/logOut')
@login_required
def logOut():
    logout_user()
    return redirect(url_for('home'))

@app.route('/confirmuser/<username>/<userhash>')
def confirmEmail(username,userhash):
    user = User.query.filter(User.username==username).first()
    if not user:
        flash('Invalid url.')
    else:
        try:
            user.userhash = ''
            user.confirmed = True
            db.session.commit()
            flash('Thanks, email has been validated. Please log in!')
        except:
            db.session.rollback()

    return redirect(url_for('logIn'))


#Error Handler
@app.errorhandler(500)
def internal_server_error(e):
    db.session.rollback()
    return render_template("500.html"), 500


@app.errorhandler(404)
def page_not_found(e):
    db.session.rollback()
    return render_template("404.html"), 404

@app.errorhandler(403)
def access_denied(e):
    db.session.rollback()
    return render_template("403.html"), 403

if __name__ == '__main__':
    app.run(debug=True)